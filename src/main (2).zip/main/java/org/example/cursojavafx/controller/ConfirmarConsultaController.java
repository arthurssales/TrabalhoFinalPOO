package org.example.cursojavafx.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import org.example.cursojavafx.HelloApplication;
import org.example.cursojavafx.model.Medico;
import org.example.cursojavafx.service.ConsultaService;
import org.example.cursojavafx.service.UsuarioLogado;

import java.io.IOException;

public class ConfirmarConsultaController {

    @FXML Button botaoVolta;
    @FXML Button botaoConfirma;
    private static Medico medicoSelecionado;

    @FXML
    public void selecionarData(){
        UsuarioLogado.getPacienteLogado().marcarConsulta(medicoSelecionado);
    }

    public static void setMedicoSelecionado(Medico medicoSelecionado1){
        medicoSelecionado = medicoSelecionado1;
    }

    @FXML
    public void confirmar(){
        ConsultaService.marcarConsulta(UsuarioLogado.getPacienteLogado(),medicoSelecionado);

        if(!ConsultaService.isIdadeValida()){
            alertarUsuario("Consulta indisponível","Idade inválida!",false);
        }

        else if(!ConsultaService.isPlanoValido()){
            alertarUsuario("Consulta indisponível!","Plano inválido!",false);
        }

        else if(ConsultaService.isAgendaLotada()){
            alertarUsuario("Consulta indisponível","Agenda lotada!\nVocê foi adicionado à lista de espera!",false);
        }

        else{
            alertarUsuario("Consulta agendada","Sua consulta foi agendada com sucesso!",true);

        }


        /*if(UsuarioLogado.getPacienteLogado().marcarConsulta(medicoSelecionado)){
            System.out.println("Consulta marcada com sucesso!");
        }




        else{
            Alert alerta = new Alert(Alert.AlertType.ERROR);
            alerta.setContentText("Consulta inválida!");
            alerta.showAndWait();
        }*/

    }

    @FXML
    public void voltar(ActionEvent event)throws IOException {
        FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("TelaMenuPaciente.fxml"));
        Scene scene = new Scene(loader.load());
        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
    }

    private void alertarUsuario(String titulo,String mensagem,boolean confirmacao){
        if(confirmacao){
            Alert alerta = new Alert(Alert.AlertType.INFORMATION);
            alerta.setHeaderText(titulo);
            alerta.setContentText(mensagem);
            alerta.showAndWait();
        }

        else{
            Alert alerta = new Alert(Alert.AlertType.ERROR);
            alerta.setHeaderText(titulo);
            alerta.setContentText(mensagem);
            alerta.showAndWait();
        }
    }
}
