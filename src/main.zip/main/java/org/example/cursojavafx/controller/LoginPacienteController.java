package org.example.cursojavafx.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.example.cursojavafx.HelloApplication;
import org.example.cursojavafx.model.Paciente;
import org.example.cursojavafx.service.PACIENTEDAO1;

import java.io.IOException;

public class LoginPacienteController {

    @FXML private TextField email;
    @FXML private TextField senha;

    @FXML private Button botaoVolta;
    @FXML private Button botaoConfirma;

    @FXML
    private void confirmar(ActionEvent event) throws IOException{
        boolean acessoPermitido = false;
        PACIENTEDAO1 pacientedao1 = new PACIENTEDAO1();

        for(Paciente paciente : PACIENTEDAO1.pacientesCadastrados){
            System.out.printf("Nome completo: %s %s - email: %s - senha: %s - sexo: %s\n",
                    paciente.getNome(),
                    paciente.getSobrenome(),
                    paciente.getEmail(),
                    paciente.getSenha(),
                    paciente.getSenha());

            if(paciente.getEmail().equals(email.getText()) && paciente.getSenha().equals(senha.getText())){
                acessoPermitido = true;
                pacientedao1.setPacienteLogado(paciente);
                break;
            }
        }

        if(acessoPermitido){
            System.out.println("Acesso permitido");

            FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("TelaMenuPaciente.fxml"));
            Parent root = loader.load();
            PacienteController controller = loader.getController();

            if (pacientedao1.getPacienteLogado().getSexo().equals("Masculino"))
                controller.setBoasVindas("Seja bem vindo,");

            else
                controller.setBoasVindas("Seja bem vinda,");

            controller.setNomePaciente(pacientedao1.getPacienteLogado().getNome());

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
        }

        else{
            System.out.println("Acesso negado");
            Alert alerta = new Alert(Alert.AlertType.ERROR);
            alerta.setContentText("Senha ou email inválido\nTente novamente");
            alerta.setHeaderText("Acesso negado");

            alerta.showAndWait();
        }
    }

    @FXML
    private void voltar(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("TelaInicial.fxml"));
        Scene scene = new Scene(loader.load(),800,600);
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
    }

}