package org.example.cursojavafx.model;

import org.example.cursojavafx.service.ConsultaService;

public class Pediatra extends Medico {

    public Pediatra(String nome,String sobrenome,String email,String senha,String sexo,int idade){
        super(nome,sobrenome,email,senha,sexo,idade);
        this.valorConsulta = 250;//depende do plano que atende
    }

    @Override
    public boolean atenderPaciente(Paciente paciente){
        if(paciente.getIdade() > 18){
            System.out.println("Idade inválida");
            ConsultaService.setIdadeValida(false);
            return false;
        }

        if(qntMaxConsulta == qntConsultas){
            System.out.println("Agenda lotada");
            ConsultaService.setAgendaLotada(true);
            filaPacientes.add(paciente);
            return false;
        }
        ConsultaService.setPlanoValido(true);
        ConsultaService.setIdadeValida(true);
        ConsultaService.setAgendaLotada(false);
        return true;
    }
}
