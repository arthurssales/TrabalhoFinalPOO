package org.example.cursojavafx.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import org.example.cursojavafx.HelloApplication;
import org.example.cursojavafx.model.Cardiologista;
import org.example.cursojavafx.model.Medico;
import org.example.cursojavafx.model.Pediatra;
import org.example.cursojavafx.model.Pneumologista;

import java.io.IOException;
import java.util.ArrayList;

public class CadastroMedicoController implements Comandos {

    public CadastroMedicoController(){
        /********VERIFICAR CAMPOS QUE ESTÃO VAZIOS***********/
    }

    @FXML
    private Button botaoConfirma;

    @FXML
    private Button botaoVolta;

    @FXML
    public void confirmar(){

    }

    @FXML
    public void voltar(ActionEvent event)throws IOException {
        FXMLLoader loader;
        loader = new FXMLLoader(HelloApplication.class.getResource("TelaInicial.fxml"));

        Scene scene = new Scene(loader.load(),800,600);

        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();

        stage.setScene(scene);
    }
}
