package org.example.cursojavafx.service;

import org.example.cursojavafx.model.*;

import java.util.ArrayList;

public class ConsultaService {
    private static boolean agendaLotada = false;
    private static boolean planoValido = true;
    private static boolean idadeValida = true;

    public static void marcarConsulta(Paciente pacienteLogado, Medico medicoSelecionado){
        medicoSelecionado.podeAtender(pacienteLogado);
    }

    public static void setIdadeValida(boolean idadeValida) {
        ConsultaService.idadeValida = idadeValida;
    }

    public static void setPlanoValido(boolean planoValido) {
        ConsultaService.planoValido = planoValido;
    }

    public static void setAgendaLotada(boolean agendaLotada) {
        ConsultaService.agendaLotada = agendaLotada;
    }

    public static boolean isIdadeValida() {
        return idadeValida;
    }

    public static boolean isPlanoValido() {
        return planoValido;
    }

    public static boolean isAgendaLotada() {
        return agendaLotada;
    }
}
