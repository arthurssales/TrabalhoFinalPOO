package org.example.cursojavafx.model;

import org.example.cursojavafx.service.ConsultaService;

public class Dermatologista extends Medico {

    public Dermatologista(String nome, String sobrenome, String email, String senha, String sexo, int idade){
        super(nome,sobrenome,email,senha,sexo,idade);
        this.valorConsulta = 200;
        qntMaxConsulta = 2;
    }

    @Override
    public boolean atenderPaciente(Paciente paciente){
        if(paciente.getPlanoA() == null){
            System.out.println("Plano inválido!");
            ConsultaService.setPlanoValido(false);
            return false;
        }

        if(qntConsultas == qntMaxConsulta){
            filaPacientes.add(paciente);
            System.out.println("Agenda lotada!");
            ConsultaService.setAgendaLotada(true);
            filaPacientes.add(paciente);
            return false;
        }

        ConsultaService.setIdadeValida(true);
        ConsultaService.setPlanoValido(true);
        ConsultaService.setAgendaLotada(false);
        return true;
    }

}
