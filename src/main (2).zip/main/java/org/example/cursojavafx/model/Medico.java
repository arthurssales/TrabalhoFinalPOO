package org.example.cursojavafx.model;

import org.example.cursojavafx.service.ConsultaService;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public abstract class Medico extends UsuarioCadastrado {
    protected double valorConsulta;
    protected int qntMaxConsulta;
    protected int qntConsultas;
    protected ArrayList<Integer> avaliacoes;
    //protected ArrayList<>
    protected ArrayList<Avaliacao> avaliacoes2 = new ArrayList<>();
    protected int somaAvaliacao = 0;
    protected double media;
    private List<Consulta> consultas = new ArrayList<>();

    protected ArrayList<Paciente> filaPacientes = new ArrayList<>();

    public double calcularMediaAvaliacao(){
        int indice;

        for(indice=0; indice< avaliacoes.toArray().length;indice++){
            somaAvaliacao += avaliacoes.get(indice);
        }

        media = (double) somaAvaliacao / avaliacoes.toArray().length;
        return media;
    }

    public double getMedia() {
        return media;
    }

    public void setMedia(double media) {
        this.media = media;
    }

    public Medico(String nome, String sobrenome, String email, String senha, String sexo, int idade){
        super(nome,sobrenome,email,senha,sexo,idade);
        this.qntConsultas = 0;
        this.qntMaxConsulta = 3;
    }

    public void adicionarConsulta(Consulta consulta){
        consultas.add(consulta);
    }

    public void adicionarFilaPaciente(Paciente paciente){
        filaPacientes.add(paciente);
    }

    public boolean podeAtender(Paciente paciente, LocalDate data){
        if(qntConsultas == qntMaxConsulta){
            System.out.println("Agenda lotada");
            ConsultaService.setAgendaLotada(true);
            filaPacientes.add(paciente);
            return false;
        }

        ConsultaService.setIdadeValida(true);
        ConsultaService.setPlanoValido(true);
        ConsultaService.setAgendaLotada(false);
        return true;
    }

    public ArrayList<Integer> getAvaliacao() {
        return avaliacoes;
    }

    public void setAvaliacao(ArrayList<Integer> avaliacoes) {
        this.avaliacoes = avaliacoes;
    }

    public int getQntMaxConsulta() {
        return qntMaxConsulta;
    }

    public void setQntMaxConsulta(int qntMaxConsulta) {
        this.qntMaxConsulta = qntMaxConsulta;
    }

    public double getValorConsulta() {
        return valorConsulta;
    }

    public void setValorConsulta(double valorConsulta) {
        this.valorConsulta = valorConsulta;
    }

    public int getQntConsultas() {
        return qntConsultas;
    }

    public void setQntConsultas(int qntConsultas) {
        this.qntConsultas = qntConsultas;
    }
}