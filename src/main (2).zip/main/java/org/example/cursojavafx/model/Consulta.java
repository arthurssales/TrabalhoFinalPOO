package org.example.cursojavafx.model;

import org.example.cursojavafx.service.CadastroUsuarioService;

import java.text.DateFormat;
import java.time.LocalDate;

public class Consulta {
    Paciente paciente;
    Medico medico;

    public Consulta(Paciente paciente, Medico medico, LocalDate data){
        this.paciente = paciente;
        this.medico = medico;
        this.data = data;
    }
    LocalDate data;
    String descricao;
    String receita;
    String examesSolicitados;
    double valorPago;





}
