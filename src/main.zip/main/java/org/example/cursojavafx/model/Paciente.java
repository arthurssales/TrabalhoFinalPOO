package org.example.cursojavafx.model;

public class Paciente extends UsuarioCadastrado {
    private int cpf;
    private boolean primeiroAcesso = true;
    //Plano plano = new Plano();

    public Paciente(String nome, String sobrenome, String email, String senha, String sexo/*,int cpf,int telefone*/) {
        super(nome,sobrenome, email, senha, sexo/*,telefone*/);
        //this.cpf = cpf;
    }


    public boolean isPrimeiroAcesso(){
        return primeiroAcesso;
    }
    public void setPrimeiroAcesso(boolean primeiroAcesso){
        this.primeiroAcesso = primeiroAcesso;
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }
}