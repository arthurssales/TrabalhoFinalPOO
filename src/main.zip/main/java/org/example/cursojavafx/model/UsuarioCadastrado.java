package org.example.cursojavafx.model;

public abstract class UsuarioCadastrado {
    protected String nome;
    protected String sobrenome;
    protected String email;
    protected String senha;
    protected String sexo;
    protected int telefone;

    protected int diaNas, mesNas, anoNas; //nascimento

    public UsuarioCadastrado(String nome, String sobrenome, String email, String senha, String sexo/*,int telefone*/){
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.email = email;
        this.senha = senha;
        this.sexo = sexo;
        //this.telefone = telefone;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    public int getAnoNas() {
        return anoNas;
    }

    public void setAnoNas(int anoNas) {
        this.anoNas = anoNas;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public int getMesNas() {
        return mesNas;
    }

    public void setMesNas(int mesNas) {
        this.mesNas = mesNas;
    }

    public int getDiaNas() {
        return diaNas;
    }

    public void setDiaNas(int diaNas) {
        this.diaNas = diaNas;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}