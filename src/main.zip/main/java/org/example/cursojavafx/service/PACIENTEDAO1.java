package org.example.cursojavafx.service;

import org.example.cursojavafx.model.Paciente;

import java.util.ArrayList;

public class PACIENTEDAO1 {
    private Paciente pacienteLogado = null;

    public static ArrayList<Paciente> pacientesCadastrados = new ArrayList<>();
    private static final Paciente paciente1 = new Paciente("Arthur","dos Santos","arthur@gmail.com","1234","Masculino");
    private static final Paciente paciente2 = new Paciente("Eduardo","Castelo Branco","dudu@gmail.com","1234","Masculino");
    private static final Paciente paciente3 = new Paciente("Luiz","Miguel Castro","luiz@gmail.com","1234","Masculino");

    public static void cadastroInicial(){
        pacientesCadastrados.add(paciente1);
        pacientesCadastrados.add(paciente2);
        pacientesCadastrados.add(paciente3);
    }

    public static void cadastrar(Paciente paciente){
        pacientesCadastrados.add(paciente);
    }

    public void setPacienteLogado(Paciente pacienteLogado) {
        this.pacienteLogado = pacienteLogado;
    }

    public Paciente getPacienteLogado(){
        return pacienteLogado;
    }

}
