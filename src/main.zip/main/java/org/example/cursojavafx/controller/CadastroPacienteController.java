package org.example.cursojavafx.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.example.cursojavafx.HelloApplication;
import org.example.cursojavafx.model.Paciente;
import org.example.cursojavafx.service.PACIENTEDAO1;
import java.io.IOException;

public class CadastroPacienteController implements Comandos{

    public void initialize(){
        nome = nomeCadastro.getText();
        sobrenome = sobrenomeCadastro.getText();
        email = emailCadastro.getText();
        senha = senhaCadastro.getText();
        confirmarSenha = confirmarSenhaCadastro.getText();

        //verificarCampos();

        /*nomeCadastro.textProperty().addListener((obs, oldVal, newVal) -> verificarCampos());
        sobrenomeCadastro.textProperty().addListener((obs,oldVal,newVal) -> verificarCampos());
        emailCadastro.textProperty().addListener((obs, oldVal, newVal) -> verificarCampos());
        senhaCadastro.textProperty().addListener((obs, oldVal, newVal) -> verificarCampos());
        confirmarSenhaCadastro.textProperty().addListener((obs,oldVal,newVal) -> verificarCampos());
        cpfCadastro.textProperty().addListener((obs,oldVal,newVal) -> verificarCampos());*/
    }

    @FXML private MenuItem botaoMasculino;
    @FXML private MenuItem botaoFeminino;

    @FXML private Button botaoVoltar;
    @FXML private Button botaoConfirmar;

    @FXML private TextField nomeCadastro;
    @FXML private TextField sobrenomeCadastro;
    @FXML private TextField emailCadastro;
    @FXML private TextField senhaCadastro;
    @FXML private TextField confirmarSenhaCadastro;
    @FXML private TextField cpfCadastro;

    String nome,sobrenome,email,senha,confirmarSenha;



    @FXML
    private void escolherPlanoA(){
    }

    @FXML
    private void escolherPlanoB(){

    }

    @FXML
    private void escolherNenhumPlano(){

    }

    @FXML
    private void escolherFeminino(){
        sexo = "Feminino";
    }

    @FXML
    private void escolherMasculino(){
        sexo = "Masculino";
    }

    //private int cpf = Integer.parseInt(cpfCadastro.getText());
    private String sexo;

    /**TRATAR A EXCESSÃO DO CPF **/

    @FXML
    public void confirmar(){
        /*ENQUANTO O USUÁRIO NÃO CONCLUIR OS DADOS, A OPÇAO DE CONFIRMAR DEVE SUMIR*/
        boolean emailExiste = false;

        for (Paciente paciente : PACIENTEDAO1.pacientesCadastrados){
            if(paciente.getEmail().equals(emailCadastro.getText())){
                emailExiste = true;
                break;
            }
        }

        if(emailExiste){
            Alert alerta = new Alert(Alert.AlertType.ERROR);
            alerta.setContentText("Esse email já foi cadastrado!");
            alerta.showAndWait();
        }

        else if(!senhaCadastro.getText().equals(confirmarSenhaCadastro.getText())) {
            Alert alerta = new Alert(Alert.AlertType.ERROR);
            alerta.setContentText("As senhas devem ser iguais!");
            alerta.showAndWait();
        }

        else{
            try{
                Alert alerta = new Alert(Alert.AlertType.CONFIRMATION);
                alerta.setContentText("Usuário cadastrado!");
                alerta.showAndWait();

                System.out.println("Paciente cadastrado!!");
                Paciente pacienteCadastrado = new Paciente(nomeCadastro.getText(),sobrenomeCadastro.getText(),emailCadastro.getText(),senhaCadastro.getText(),sexo/*,12,123444*/);
                PACIENTEDAO1.cadastrar(pacienteCadastrado);
                System.out.println("Nome: " + pacienteCadastrado.getNome());
                System.out.println("email: " + pacienteCadastrado.getEmail());
                System.out.println("senha: " + pacienteCadastrado.getSenha());
                System.out.println("Sexo: " + pacienteCadastrado.getSexo());

                nomeCadastro.setText(null);
                sobrenomeCadastro.setText(null);
                emailCadastro.setText(null);
                senhaCadastro.setText(null);
                confirmarSenhaCadastro.setText(null);
                cpfCadastro.setText(null);

            } catch (Exception e) {
                Alert alerta = new Alert(Alert.AlertType.ERROR);
                alerta.setContentText("Preencha todas as informações corretamente!");
                alerta.setHeaderText("Campo vazio");
                alerta.showAndWait();
            }
            /*----------DEBUG------------------*/
            for(Paciente paciente : PACIENTEDAO1.pacientesCadastrados){
                System.out.printf("Nome completo: %s %s - Email: %s - Senha: %s - sexo: %s\n",
                        paciente.getNome(),
                        paciente.getSobrenome(),
                        paciente.getEmail(),
                        paciente.getSenha(),
                        paciente.getSexo());
            }
        }
    }

    @FXML
    public void voltar(ActionEvent event)throws IOException{
        FXMLLoader loader;
        loader = new FXMLLoader(HelloApplication.class.getResource("TelaInicial.fxml"));

        Scene scene = new Scene(loader.load(),800,600);

        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();

        stage.setScene(scene);
    }

    public void verificarCampos(){
        boolean camposVazios = nome == (null)
                || sobrenome == null
                || email == null
                || senha == null
                || confirmarSenha == null
                || sexo == null;
            botaoConfirmar.setDisable(camposVazios);
    }
}
