package org.example.cursojavafx.model;

public class PlanoA{
    private final String nome;
    private final double valorPorConsulta;

    public PlanoA(){
        nome = "Plano A";
        valorPorConsulta = 120;
    }

    public String getNome() {
        return nome;
    }

    public double getValorPorConsulta() {
        return valorPorConsulta;
    }
}
